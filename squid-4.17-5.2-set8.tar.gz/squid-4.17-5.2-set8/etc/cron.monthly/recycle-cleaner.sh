#!/bin/bash

# Скрипт автоматической очистки корзины Samba
[[ -d /usr/local/Common/.recycle ]] && find /usr/local/Common/.recycle/* -ctime +30 -delete
