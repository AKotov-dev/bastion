#!/bin/bash

multitail /var/log/squid/access.log
