#!/bin/bash

#Интерфейсы WAN/LAN
wan="enp0s3"
lan="enp0s8"
#-----------------//----------------

#Списки /etc/squid/*.txt: удаление пробелов, дубликатов, сортировка
for i in $(ls /etc/squid/*.txt); do
    sed -i 's/^[ \t]*//;s/[ \t]*$//;/^[[:space:]]*$/d' $i
    if [ "$i" == "/etc/squid/vip-users.txt" ]; then
	sort -u -t . -k 3,3n -k 4,4n $i > $i.tmp; mv -f $i.tmp $i
	    else
	sort -u $i > $i.tmp; mv -f $i.tmp $i
    fi;
done;

#Загрузка нужных модулей ядра
modprobe ip_set; modprobe xt_string

#Проверка автозапуска Bastion
[[ "$(systemctl is-enabled bastion)" == "disabled" ]] && systemctl enable bastion
#Отключение iptables, squid, httpd (всё запускает Bastion)
[[ "$(systemctl is-enabled iptables)" == "enabled" ]] && systemctl disable iptables
[[ "$(systemctl is-enabled squid)" == "enabled" ]] && systemctl disable squid
[[ "$(systemctl is-enabled httpd)" == "enabled" ]] && systemctl disable httpd
#Останов/отключение msec и shorewall (всё настраивает Bastion)
[[ "$(systemctl is-active msec)" == "active" ]] && systemctl stop msec
[[ "$(systemctl is-active shorewall)" == "active" ]] && systemctl stop shorewall
[[ "$(systemctl is-enabled msec)" == "enabled" ]] && systemctl disable msec
[[ "$(systemctl is-enabled shorewall)" == "enabled" ]] && systemctl disable shorewall
#Отключение dnsmasq
[[ "$(systemctl is-enabled dnsmasq)" == "enabled" ]] && systemctl disable dnsmasq
#Отключение smb/nmb
[[ "$(systemctl is-enabled smb)" == "enabled" ]] && systemctl disable smb nmb

#Включаем форвардинг пакетов IPv4
sysctl -w net.ipv4.ip_forward=1

#Очистка iptables
iptables -F; iptables -X
iptables -t nat -F; iptables -t nat -X
iptables -t mangle -F; iptables -t mangle -X

#Всё, кроме INPUT
iptables -P INPUT DROP; iptables -P OUTPUT ACCEPT; iptables -P FORWARD ACCEPT

#Разрешаем lo и уже установленные соединения
iptables -A INPUT -i lo -j ACCEPT
iptables -A INPUT -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT

#Разрешаем пинг
iptables -A INPUT -p icmp --icmp-type echo-reply -j ACCEPT
iptables -A INPUT -p icmp --icmp-type echo-request -j ACCEPT

#Открываем SSH:22 + защита от брутфорса (3 попытки подключения => бан атакующего на 60 сек)
iptables -A INPUT -p tcp --syn --dport 22 -m recent --name sshport --set
iptables -A INPUT -p tcp --syn --dport 22 -m recent --name sshport --update --seconds 60 --hitcount 4 -j DROP

#Удалённый доступ по SSH:22
iptables -A INPUT -p tcp -m multiport --dports 22 -j ACCEPT

#Разрешаем Samba, DHCP/DNS (dnsmasq, если будет)
iptables -A INPUT -i $lan -p tcp -m multiport --dports 137:139,445 -j ACCEPT
iptables -A INPUT -i $lan -p udp -m multiport --dports 137:139,445,53,67,68,1024:65535 -j ACCEPT

#Прозрачный прокси
iptables -A INPUT -i $lan -p tcp -m multiport --dports 3128,3129,3130 -j ACCEPT
iptables -A INPUT -i $lan -p udp -m multiport --dports 3128,3129,3130 -j ACCEPT

#Блокировка IPSET по множеству IP-адресов
#[[ $(ipset -L) ]] || ipset -N blacklist iphash; ipset -F blacklist
#for site in $(cat /etc/squid/blacklist.txt); do
#   for ip in $(host $(echo $site | sed 's/^\.//') | grep "has address" | cut -d " " -f4); do
#     ipset -A blacklist $ip
#   done
#done;
#iptables -A FORWARD -i $lan -m set --match-set blacklist dst -j REJECT

#Блокировка STRING (словарная фильтрация)
#for site in $(cat /etc/squid/blacklist.txt); do
#    iptables -A FORWARD -i $lan -m string --string "$(echo $site | sed 's/^\.//')" --algo bm -j REJECT
#done;

#Заворачиваем HTTP/HTTPS на Squid
iptables -t nat -i $lan -A PREROUTING -p tcp --dport 80 -j REDIRECT --to-port 3129
iptables -t nat -i $lan -A PREROUTING -p tcp --dport 443 -j REDIRECT --to-port 3130

#Секция маскардинга
iptables -A FORWARD -i $wan -o $lan -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT
iptables -A FORWARD -i $lan -o $wan -j ACCEPT
iptables -t nat -A POSTROUTING -o $wan -j MASQUERADE

#Сохраняем и перезапускаем iptables, squid, httpd и dnsmasq (по флагу)
/usr/sbin/iptables-save -c > /etc/sysconfig/iptables; systemctl restart iptables
[[ $(pidof squid) ]] && squid -k reconfigure || systemctl restart squid
systemctl restart httpd

#Запуск/Останов dnsmasq
if [[ -f /etc/squid/dnsmasq-start && -z $(pidof dnsmasq) ]]; then
systemctl restart dnsmasq
  elif [[ ! -f /etc/squid/dnsmasq-start ]]; then
systemctl stop dnsmasq
fi;

#Запуск/Останов smb/nmb
if [[ -f /etc/squid/samba-start && -z $(pidof smbd) ]]; then
systemctl restart smb nmb crond.service
  elif [[ ! -f /etc/squid/samba-start ]]; then
systemctl stop smb
fi;

exit 0;
