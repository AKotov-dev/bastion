#!/bin/bash

#Нужны пакеты ipset, bind-utils (host), apache

#Интерфейсы и пути
wan="enp0s3"
lan="enp0s8"
#-----------------//----------------

#Отключаем протокол IPv6
sysctl -w net.ipv6.conf.all.disable_ipv6=1
sysctl -w net.ipv6.conf.default.disable_ipv6=1
sysctl -w net.ipv6.conf.lo.disable_ipv6=1

#Включаем форвардинг пакетов IPv4
sysctl -w net.ipv4.ip_forward=1

#Очистка iptables
iptables -F; iptables -X
iptables -t nat -F; iptables -t nat -X
iptables -t mangle -F; iptables -t mangle -X

#Всё, кроме INPUT
iptables -P INPUT DROP; iptables -P OUTPUT ACCEPT; iptables -P FORWARD ACCEPT

#Разрешаем lo и уже установленные соединения
iptables -A INPUT -i lo -j ACCEPT
iptables -A INPUT -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT

#Разрешаем пинг
iptables -A INPUT -p icmp --icmp-type echo-reply -j ACCEPT
iptables -A INPUT -p icmp --icmp-type echo-request -j ACCEPT

#Открываем SSH:22 + защита от брутфорса (3 попытки подключения => бан атакующего на 60 сек)
iptables -A INPUT -p tcp --syn --dport 22 -m recent --name sshport --set
iptables -A INPUT -p tcp --syn --dport 22 -m recent --name sshport --update --seconds 60 --hitcount 4 -j DROP

#Удалённый доступ по SSH
iptables -A INPUT -p tcp -m multiport --dports 22 -j ACCEPT

#Разрешаем Samba, DHCP/DNS и SSH:22 (dnsmasq и openssh-server, если они будут)
iptables -A INPUT -i $lan -p tcp -m multiport --dports 137:139,445 -j ACCEPT
iptables -A INPUT -i $lan -p udp -m multiport --dports 137:139,445,53,67,68,1024:65535 -j ACCEPT

#Прозрачный прокси
iptables -A INPUT -i $lan -p tcp -m multiport --dports 3128,3129,3130 -j ACCEPT
iptables -A INPUT -i $lan -p udp -m multiport --dports 3128,3129,3130 -j ACCEPT

#Блокировка IPSET по множеству IP-адресов
[[ $(ipset -L) ]] || ipset -N blacklist iphash; ipset -F blacklist
for site in $(cat /etc/squid/blacklist.txt); do
   for ip in $(host $site | grep "has address" | cut -d " " -f4); do
     ipset -A blacklist $ip
   done
done;
iptables -A FORWARD -i $lan -m set --match-set blacklist dst -j REJECT

#Блокировка STRING (словарная фильтрация)
for site in $(cat /etc/squid/blacklist.txt); do
    iptables -A FORWARD -i $lan -m string --string "$site" --algo bm -j REJECT
done;

#Секция маскардинга
iptables -t nat -i $lan -A PREROUTING -p tcp --dport 80 -j REDIRECT --to-port 3129
iptables -t nat -i $lan -A PREROUTING -p tcp --dport 443 -j REDIRECT --to-port 3130

iptables -A FORWARD -i $wan -o $lan -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT
iptables -A FORWARD -i $lan -o $wan -j ACCEPT
iptables -t nat -A POSTROUTING -o $wan -j MASQUERADE

#Сохраняем и перезапускаем iptables
#systemctl enable iptables
/usr/sbin/iptables-save -c > /etc/sysconfig/iptables; systemctl restart iptables
[[ $(pidof squid) ]] && squid -k reconfigure || systemctl restart squid
systemctl restart httpd

exit 0;
