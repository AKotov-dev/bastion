#!/bin/bash

#Проверка автозапуска Bastion
[[ "$(systemctl is-enabled bastion)" == "disabled" ]] && systemctl enable bastion
#Удаление старых сертификатов
rm -f /etc/squid/{*.pem,*.der,*.default}

#urpmi --auto squid iptables ipset bind-utils openssh-server multitail apache squidanalyzer
#systemctl stop squid; systemctl disable squid
#systemctl disable iptables; systemctl enable httpd; systemctl enable bastion

#Сгенерируем свой сертификат… лет на 100 лет; proxyCA.pem — и сертификат и ключ в одном файле
cd /etc/squid
openssl req -new -newkey rsa:2048 -sha256 -days 36500 -nodes -x509 -extensions v3_ca -keyout proxyCA.pem -out proxyCA.pem
#Создадим сертификат для установки его на компьютеры пользователей (корневой)
openssl x509 -in proxyCA.pem -outform DER -out squid.der

#Скопируем squid.der на свой компьютер, это сертификат для установки его на клиентские
#компьютеры. Установим его либо руками, либо групповой политикой.

#Генерируем файл параметров
openssl dhparam -outform PEM -out bump_dhparam.pem 2048
#Настроим права на использование файла SSL-сертификата и файла параметров
chown squid:squid bump_dhparam.pem
chmod 400 bump_dhparam.pem
chown squid:squid proxyCA.pem
chmod 400 proxyCA.pem
#Выставляем права на /var/spool/squid/ и /var/log/squid/
chown squid:squid -R /var/spool/squid
chown squid:squid -R /var/log/squid
#Создаем каталог для базы данных сертификатов и инициализируем базу данных
mkdir -p /var/lib/squid
rm -rf /var/lib/squid/ssl_db
/usr/lib64/squid/security_file_certgen -c -s /var/lib/squid/ssl_db -M 4MB
chown -R squid:squid /var/lib/squid

#Рестарт Squid
#systemctl restart squid

echo; read -p "Press Enter to continue..."

exit 0;
